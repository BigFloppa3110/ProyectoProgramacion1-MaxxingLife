package co.edu.unbosque.Model;

import java.io.Serializable;

/**
 * 
 * 
 * @author Jose Suarez
 * 
 * 
 */

/**
 * La clase {JuegoModel} representa un juego en el que un apostador puede participar.
 * Contiene informaci�n como el nombre del juego, tipo de juego, resultado, dinero invertido y victorias.
 */
public class JuegoModel implements Serializable {
    private String nombreJuego;
    private String tipoJuego;
    private String resultado;
    private double dineroInvertido;
    private int victorias;

    /**
     * Constructor de la clase {JuegoModel}.
     * @param nombreJuego El nombre del juego.
     * @param dineroInvertido El dinero invertido en el juego.
     * @param victorias El n�mero de victorias en el juego.
     * @param tipoJuego El tipo de juego.
     * @param resultado El resultado del juego.
     */
    public JuegoModel(String nombreJuego, double dineroInvertido, int victorias, String tipoJuego, String resultado) {
        this.nombreJuego = nombreJuego;
        this.dineroInvertido = dineroInvertido;
        this.victorias = victorias;
        this.tipoJuego = tipoJuego;
        this.resultado = resultado;
    }

    /**
     * Obtiene el nombre del juego.
     * @return El nombre del juego.
     */
    public String getNombreJuego() {
        return nombreJuego;
    }

    /**
     * Establece el nombre del juego.
     * @param nombreJuego El nuevo nombre del juego.
     */
    public void setNombreJuego(String nombreJuego) {
        this.nombreJuego = nombreJuego;
    }

    /**
     * Obtiene el tipo de juego.
     * @return El tipo de juego.
     */
    public String getTipoJuego() {
        return tipoJuego;
    }

    /**
     * Establece el tipo de juego.
     * @param tipoJuego El nuevo tipo de juego.
     */
    public void setTipoJuego(String tipoJuego) {
        this.tipoJuego = tipoJuego;
    }

    /**
     * Obtiene el resultado del juego.
     * @return El resultado del juego.
     */
    public String getResultado() {
        return resultado;
    }

    /**
     * Establece el resultado del juego.
     * @param resultado El nuevo resultado del juego.
     */
    public void setResultado(String resultado) {
        this.resultado = resultado;
    }

    /**
     * Obtiene el dinero invertido en el juego.
     * @return El dinero invertido en el juego.
     */
    public double getDineroInvertido() {
        return dineroInvertido;
    }

    /**
     * Establece el dinero invertido en el juego.
     * @param dineroInvertido El nuevo dinero invertido en el juego.
     */
    public void setDineroInvertido(double dineroInvertido) {
        this.dineroInvertido = dineroInvertido;
    }

    /**
     * Obtiene el n�mero de victorias en el juego.
     * @return El n�mero de victorias en el juego.
     */
    public int getVictorias() {
        return victorias;
    }

    /**
     * Establece el n�mero de victorias en el juego.
     * @param victorias El nuevo n�mero de victorias en el juego.
     */
    public void setVictorias(int victorias) {
        this.victorias = victorias;
    }

    /**
     * Devuelve una representaci�n en cadena del juego.
     * @return Una cadena que representa el juego.
     */
    @Override
    public String toString() {
        return "Juego: " + nombreJuego + "\nDinero Invertido: $" + dineroInvertido + "\nVictorias: " + victorias;
    }
}

