package co.edu.unbosque.Model;

import java.io.Serializable;

/**
 * 
 * 
 * @author Jose Suarez
 * 
 * 
 */

/**
 * La clase {ApostadorModel} representa a un apostador en la casa de apuestas.
 * Contiene informaci�n como el nombre completo, c�dula, sede, direcci�n y n�mero de celular del apostador.
 */
public class ApostadorModel implements Serializable {
    private String nombreCompleto;
    private String cedula;
    private String sede;
    private String direccion;
    private String celular;

    /**
     * Constructor de la clase {ApostadorModel}.
     * @param nombreCompleto El nombre completo del apostador.
     * @param cedula La c�dula del apostador.
     * @param sede La sede a la que pertenece el apostador.
     * @param direccion La direcci�n del apostador.
     * @param celular El n�mero de celular del apostador.
     */
    public ApostadorModel(String nombreCompleto, String cedula, String sede, String direccion, String celular) {
        this.nombreCompleto = nombreCompleto;
        this.cedula = cedula;
        this.sede = sede;
        this.direccion = direccion;
        this.celular = celular;
    }

    /**
     * Obtiene el nombre completo del apostador.
     * @return El nombre completo del apostador.
     */
    public String getNombreCompleto() {
        return nombreCompleto;
    }

    /**
     * Establece el nombre completo del apostador.
     * @param nombreCompleto El nuevo nombre completo del apostador.
     */
    public void setNombreCompleto(String nombreCompleto) {
        this.nombreCompleto = nombreCompleto;
    }

    /**
     * Obtiene la c�dula del apostador.
     * @return La c�dula del apostador.
     */
    public String getCedula() {
        return cedula;
    }

    /**
     * Establece la c�dula del apostador.
     * @param cedula La nueva c�dula del apostador.
     */
    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    /**
     * Obtiene la sede a la que pertenece el apostador.
     * @return La sede del apostador.
     */
    public String getSede() {
        return sede;
    }

    /**
     * Establece la sede a la que pertenece el apostador.
     * @param sede La nueva sede del apostador.
     */
    public void setSede(String sede) {
        this.sede = sede;
    }

    /**
     * Obtiene la direcci�n del apostador.
     * @return La direcci�n del apostador.
     */
    public String getDireccion() {
        return direccion;
    }

    /**
     * Establece la direcci�n del apostador.
     * @param direccion La nueva direcci�n del apostador.
     */
    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    /**
     * Obtiene el n�mero de celular del apostador.
     * @return El n�mero de celular del apostador.
     */
    public String getCelular() {
        return celular;
    }

    /**
     * Establece el n�mero de celular del apostador.
     * @param celular El nuevo n�mero de celular del apostador.
     */
    public void setCelular(String celular) {
        this.celular = celular;
    }
}

