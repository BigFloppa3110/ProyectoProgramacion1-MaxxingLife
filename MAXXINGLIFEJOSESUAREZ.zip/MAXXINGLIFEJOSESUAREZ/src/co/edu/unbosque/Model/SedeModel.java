package co.edu.unbosque.Model;

/**
 * 
 * 
 * @author Jose Suarez
 * 
 * 
 */

/**
 * La clase {SedeModel} representa una sede de la casa de apuestas.
 * Contiene informaci�n como la ubicaci�n y el n�mero de empleados.
 */
public class SedeModel {
    private String ubicacion;
    private int numeroEmpleados;

    /**
     * Constructor de la clase {SedeModel}.
     * @param ubicacion La ubicaci�n de la sede.
     * @param numeroEmpleados El n�mero de empleados de la sede.
     */
    public SedeModel(String ubicacion, int numeroEmpleados) {
        this.ubicacion = ubicacion;
        this.numeroEmpleados = numeroEmpleados;
    }

    /**
     * Obtiene la ubicaci�n de la sede.
     * @return La ubicaci�n de la sede.
     */
    public String getUbicacion() {
        return ubicacion;
    }

    /**
     * Establece la ubicaci�n de la sede.
     * @param ubicacion La nueva ubicaci�n de la sede.
     */
    public void setUbicacion(String ubicacion) {
        this.ubicacion = ubicacion;
    }

    /**
     * Obtiene el n�mero de empleados de la sede.
     * @return El n�mero de empleados de la sede.
     */
    public int getNumeroEmpleados() {
        return numeroEmpleados;
    }

    /**
     * Establece el n�mero de empleados de la sede.
     * @param numeroEmpleados El nuevo n�mero de empleados de la sede.
     */
    public void setNumeroEmpleados(int numeroEmpleados) {
        this.numeroEmpleados = numeroEmpleados;
    }
}
