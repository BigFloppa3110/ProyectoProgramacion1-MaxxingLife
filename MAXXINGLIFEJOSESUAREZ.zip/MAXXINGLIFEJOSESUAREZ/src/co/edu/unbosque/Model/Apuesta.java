package co.edu.unbosque.Model;

/**
 * 
 * 
 * @author Jose Suarez
 * 
 * 
 */

public class Apuesta {
	 private String cedulaApostador;

	public Object getCedulaApostador() {
		return null;
	}

}
