package co.edu.unbosque.Model;

import java.io.Serializable;

/**
 * 
 * 
 * @author Jose Suarez
 * 
 * 
 */

/**
 * La clase {ApuestaModel} representa una apuesta realizada por un apostador.
 * Contiene informaci�n como la sede, c�dula del apostador, d�a de la apuesta, valor de la apuesta,
 * tipo de juego y datos espec�ficos de la apuesta.
 */
public class ApuestaModel implements Serializable {
    private String sede;
    private String cedula;
    private String dia;
    private double valorApuesta;
    private String tipoJuego;
    private Object datosEspecificos;

    /**
     * Constructor de la clase {ApuestaModel}.
     * @param sede La sede donde se realiza la apuesta.
     * @param cedula La c�dula del apostador que realiza la apuesta.
     * @param dia El d�a en que se realiza la apuesta.
     * @param valorApuesta El valor apostado.
     * @param tipoJuego El tipo de juego al que se realiza la apuesta.
     * @param datosEspecificos Datos espec�ficos de la apuesta, que pueden variar seg�n el tipo de juego.
     */
    public ApuestaModel(String sede, String cedula, String dia, double valorApuesta, String tipoJuego, Object datosEspecificos) {
        this.sede = sede;
        this.cedula = cedula;
        this.dia = dia;
        this.valorApuesta = valorApuesta;
        this.tipoJuego = tipoJuego;
        this.datosEspecificos = datosEspecificos;
    }

    /**
     * Obtiene la sede donde se realiza la apuesta.
     * @return La sede de la apuesta.
     */
    public String getSede() {
        return sede;
    }

    /**
     * Establece la sede donde se realiza la apuesta.
     * @param sede La nueva sede de la apuesta.
     */
    public void setSede(String sede) {
        this.sede = sede;
    }

    /**
     * Obtiene la c�dula del apostador que realiza la apuesta.
     * @return La c�dula del apostador.
     */
    public String getCedula() {
        return cedula;
    }

    /**
     * Establece la c�dula del apostador que realiza la apuesta.
     * @param cedula La nueva c�dula del apostador.
     */
    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    /**
     * Obtiene el d�a en que se realiza la apuesta.
     * @return El d�a de la apuesta.
     */
    public String getDia() {
        return dia;
    }

    /**
     * Establece el d�a en que se realiza la apuesta.
     * @param dia El nuevo d�a de la apuesta.
     */
    public void setDia(String dia) {
        this.dia = dia;
    }

    /**
     * Obtiene el valor apostado.
     * @return El valor de la apuesta.
     */
    public double getValorApuesta() {
        return valorApuesta;
    }

    /**
     * Establece el valor apostado.
     * @param valorApuesta El nuevo valor de la apuesta.
     */
    public void setValorApuesta(double valorApuesta) {
        this.valorApuesta = valorApuesta;
    }

    /**
     * Obtiene la c�dula del apostador que realiza la apuesta.
     * @return La c�dula del apostador.
     */
    public Object getCedulaApostador() {
        return cedula;
    }
}

