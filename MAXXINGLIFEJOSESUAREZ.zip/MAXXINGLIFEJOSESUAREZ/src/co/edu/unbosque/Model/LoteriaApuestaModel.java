package co.edu.unbosque.Model;

import java.io.Serializable;

/**
 * 
 * 
 * @author Jose Suarez
 * 
 * 
 */

public class LoteriaApuestaModel extends ApuestaModel implements Serializable {
    private String nombreLoteria;
    private int[] numeros;
    private String serie;

    public LoteriaApuestaModel(String sede, String cedula, String dia, double valorApuesta, String nombreLoteria, int[] numeros, String serie) {
        super(sede, cedula, dia, valorApuesta, "Loteria", null);
        this.nombreLoteria = nombreLoteria;
        this.numeros = numeros;
        this.serie = serie;
    }
}

