package co.edu.unbosque.Controller;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import co.edu.unbosque.Model.ApostadorModel;
import co.edu.unbosque.Model.JuegoModel;

/**
 * 
 * 
 * @author Jose Suarez
 * 
 * 
 */


/**
 * La clase {JuegoController} gestiona los juegos de la Casa de Apuestas.
 * Permite cargar, guardar y realizar operaciones relacionadas con los juegos.
 */
public class JuegoController implements Serializable {
    private List<JuegoModel> juegos;
    private static final String JUEGOS_FILE = "juegos.dat";

    /**
     * Constructor de la clase {JuegoController}.
     * Inicializa la lista de juegos y carga los juegos existentes si el archivo ya existe.
     */
    public JuegoController() {
        juegos = new ArrayList<>();
        cargarJuegos();
    }

    /**
     * Guarda los juegos en el archivo correspondiente.
     */
    public void guardarJuegos() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(JUEGOS_FILE))) {
            oos.writeObject(juegos);
            System.out.println("Juegos guardados: " + juegos.size());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Carga los juegos desde el archivo correspondiente.
     * Si el archivo no existe, crea uno nuevo y lo guarda.
     */
    public void cargarJuegos() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(JUEGOS_FILE))) {
            Object obj = ois.readObject();

            if (obj instanceof ArrayList<?>) {
                juegos = (ArrayList<JuegoModel>) obj;
                System.out.println("Juegos cargados: " + juegos.size());
            } else {
                System.out.println("Error: El objeto le�do no es una instancia de ArrayList<JuegoModel>");
            }

        } catch (FileNotFoundException e) {
            System.out.println("El archivo juegos.dat no existe. Se crear� uno nuevo.");
            guardarJuegos(); 
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    /**
     * Obtiene la lista de juegos asociados a un apostador espec�fico.
     * @param apostadorActual El apostador del cual se desean obtener los juegos.
     * @return La lista de juegos asociados al apostador.
     */
    public ArrayList<JuegoModel> obtenerJuegosDelApostador(ApostadorModel apostadorActual) {
        return null;
    }
}


