package co.edu.unbosque.Controller;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.io.*;
import co.edu.unbosque.Model.*;

/**
 * 
 * 
 * @author Jose Suarez
 * 
 * 
 */

/**
 * La clase { ApostadorController} gestiona la informaci�n de los apostadores.
 * Permite crear, cargar, guardar, eliminar, imprimir y registrar apostadores.
 * Adem�s, implementa la interfaz Serializable para poder almacenar los datos en un archivo binario.
 */
public class ApostadorController implements Serializable {
    private ArrayList<ApostadorModel> apostadores;
    private static final String APOSTADORES_FILE = "apostadores.dat";

    /**
     * Constructor de la clase {ApostadorController}.
     * Inicializa la lista de apostadores y carga los datos desde el archivo apostadores.dat.
     */
    public ApostadorController() {
        apostadores = new ArrayList<>();
        cargarApostadores();
    }

    /**
     * Crea un nuevo apostador con la informaci�n proporcionada y lo agrega a la lista de apostadores.
     * nombreCompleto El nombre completo del apostador.
     * edula La c�dula del apostador.
     * sede La sede del apostador.
     * direccion La direcci�n del apostador.
     * celular El n�mero de celular del apostador.
     */
    public void crearApostador(String nombreCompleto, String cedula, String sede, String direccion, String celular) {
        if (!nombreCompleto.trim().isEmpty() && !cedula.trim().isEmpty()) {
            ApostadorModel apostador = new ApostadorModel(nombreCompleto, cedula, sede, direccion, celular);
            guardarApostadores();
        } else {
            System.out.println("Error: Nombre o c�dula en blanco, no se cre� el apostador.");
        }
    }

    /**
     * Obtiene la lista de apostadores.
     * return La lista de apostadores.
     */
    public ArrayList<ApostadorModel> obtenerApostadores() {
        if (apostadores == null) {
            apostadores = new ArrayList<>();
        }
        return apostadores;
    }

    /**
     * Carga la lista de apostadores desde el archivo apostadores.dat.
     */
    public void cargarApostadores() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(APOSTADORES_FILE))) {
            Object obj = ois.readObject();

            if (obj instanceof ArrayList<?>) {
                apostadores = (ArrayList<ApostadorModel>) obj;
                System.out.println("Apostadores cargados: " + apostadores.size());
            } else {
                System.out.println("Error: El objeto le�do no es una instancia de ArrayList<ApostadorModel>");
            }
        } catch (FileNotFoundException e) {
            System.out.println("El archivo apostadores.dat no existe. Se crear� uno nuevo.");
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    /**
     * Guarda la lista de apostadores en el archivo apostadores.dat.
     */
    public void guardarApostadores() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(APOSTADORES_FILE))) {
            oos.writeObject(apostadores);
            System.out.println("Apostadores guardados: " + apostadores.size());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Elimina un apostador de la lista seg�n su c�dula y guarda la lista actualizada.
     * cedulaApostador La c�dula del apostador a eliminar.
     */
    public void eliminarApostador(String cedulaApostador) {
        Iterator<ApostadorModel> iterator = apostadores.iterator();
        while (iterator.hasNext()) {
            ApostadorModel apostador = iterator.next();
            if (cedulaApostador != null && cedulaApostador.equals(apostador.getCedula())) {
                iterator.remove();
                guardarApostadores();
                System.out.println("Apostador eliminado: " + apostador);
                break;
            }
        }
    }

    /**
     * Imprime la informaci�n de todos los apostadores en la consola.
     */
    public void imprimirInformacionApostadores() {
        System.out.println("Informaci�n de apostadores:");
        for (ApostadorModel apostador : apostadores) {
            System.out.println(apostador);
        }
    }

    /**
     * Registra un nuevo apostador en la lista y guarda la lista actualizada.
     * apostador El apostador a registrar.
     */
    public void registrarApostador(ApostadorModel apostador) {
        apostadores.add(apostador);
        guardarApostadores();
        System.out.println("Apostador registrado: " + apostador);
    }
}
