package co.edu.unbosque.Controller;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.swing.JOptionPane;
import java.io.*;
import co.edu.unbosque.Model.*;

/**
 * 
 * 
 * @author Jose Suarez
 * 
 * 
 */


/**
 * La clase {ApuestaController} gestiona las apuestas realizadas por los apostadores.
 * Permite crear, cargar, eliminar y obtener apuestas, as� como ingresar a la interfaz de diferentes juegos.
 */
public class ApuestaController {
    private ArrayList<ApuestaModel> apuestas;
    
    /**
     * Constructor de la clase {ApuestaController}.
     * Inicializa la lista de apuestas y elimina los archivos de apuestas existentes.
     */
    public ApuestaController() {
        apuestas = new ArrayList<>();
        cargarApuestas();
        eliminarApuestas();
    }
    
    /**
     * Carga la lista de apuestas desde los archivos correspondientes.
     */
    private void cargarApuestas() {
		
	}


    /**
     * Crea una nueva apuesta con la informaci�n proporcionada y la agrega a la lista de apuestas.
     * sede La sede de la apuesta.
     * cedulaApostador La c�dula del apostador que realiza la apuesta.
     * dia El d�a en que se realiza la apuesta.
     * valorApuesta El valor apostado.
     * tipoJuego El tipo de juego al que se est� apostando.
     * datosEspecificos Datos espec�ficos de la apuesta, como n�meros o informaci�n adicional.
     */
	public void crearApuesta(String sede, String cedula, String dia, double valorApuesta, String tipoJuego, Object datosEspecificos) {
        ApuestaModel apuesta = new ApuestaModel(sede, cedula, dia, valorApuesta, tipoJuego, datosEspecificos);
        apuestas.add(apuesta);
    }

	public void crearLoteriaApuesta(String string, String cedulaApostador, String string2, double d, String string3,
			int[] numerosLoteria, String serieLoteria) {
		
	}
	
	
	/**
     * Elimina todas las apuestas realizadas por un apostador.
     * cedulaApostador La c�dula del apostador cuyas apuestas se eliminar�n.
     */
	public void eliminarApostador(String cedulaApostador) {
        Iterator<ApuestaModel> iterator = apuestas.iterator();
        while (iterator.hasNext()) {
            ApuestaModel apuesta = iterator.next();
            if (apuesta.getCedulaApostador().equals(cedulaApostador)) {
                iterator.remove();
                System.out.println("Apostador eliminado correctamente.");
                break;
            }
        }
    }
        
	/**
     * Obtiene la lista de apuestas.
     * @return La lista de apuestas.
     */
	private List<Apuesta> obtenerApuestas() {
		return null;
    }

	/**
     * Guarda la lista de apuestas actualizada en los archivos correspondientes.
     * @param apuestas La lista de apuestas a guardar.
     */
    private void guardarApuestas(List<Apuesta> apuestas) {
    }
    
    /**
     * Ingresa a la interfaz del juego seleccionado seg�n su nombre.
     * @param juegoSeleccionado El nombre del juego al que se desea ingresar.
     * @param cedulaApostador La c�dula del apostador que realiza la apuesta.
     */
    public void ingresarJuego(String juegoSeleccionado, String cedulaApostador) {

        switch (juegoSeleccionado.toLowerCase()) {
            case "loter�a":
                break;
            case "superastro":
                break;
            case "Baloto":
                break;
            case "BetPlay":
                break;
            case "Chance":
                break;
            default:
                JOptionPane.showMessageDialog(null, "Juego no reconocido", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * Elimina los archivos de apuestas existentes para iniciar una nueva sesi�n.
     */
	public void eliminarApuestas() {
        String[] tiposJuegos = {"loteria", "superastro", "baloto", "betplay", "chance"};

        for (String tipoJuego : tiposJuegos) {
            String nombreArchivo = "apuestas-" + tipoJuego + ".dat";
            File archivo = new File(nombreArchivo);

            if (archivo.exists()) {
                if (archivo.delete()) {
                    System.out.println("Archivo " + nombreArchivo + " eliminado exitosamente.");
                } else {
                    System.out.println("Error al intentar eliminar el archivo " + nombreArchivo);
                }
            } else {
                System.out.println("El archivo " + nombreArchivo + " no existe.");
            }
        }
    }


}
