package co.edu.unbosque.Controller;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Properties;

/**
 * 
 * 
 * @author Jose Suarez
 * 
 * 
 */

/**
 * La clase {ConfiguracionController} gestiona la configuraci�n de la Casa de Apuestas utilizando un archivo de propiedades.
 * Permite cargar y guardar la configuraci�n, as� como obtener y establecer valores espec�ficos como el nombre de la casa, n�mero de sedes y presupuesto total.
 */
public class ConfiguracionController {
    private Properties properties;
    private static final String CONFIG_FILE = "config.properties";

    /**
     * Constructor de la clase {ConfiguracionController}.
     * Inicializa la instancia de {@code Properties} y carga la configuraci�n existente.
     */
    public ConfiguracionController() {
        properties = new Properties();
        cargarConfiguracion();
    }

    /**
     * Carga la configuraci�n desde el archivo de propiedades.
     */
    public void cargarConfiguracion() {
        try (InputStream input = new FileInputStream(CONFIG_FILE)) {
            properties.load(input);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Guarda la configuraci�n en el archivo de propiedades.
     */
    public void guardarConfiguracion() {
        try (OutputStream output = new FileOutputStream(CONFIG_FILE)) {
            properties.store(output, null);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    /**
     * Obtiene el nombre de la casa de apuestas desde la configuraci�n.
     * @return El nombre de la casa de apuestas o "Casa de Apuestas" por defecto.
     */
    public String obtenerNombreCasaApuestas() {
        return properties.getProperty("nombreCasaApuestas", "Casa de Apuestas");
    }

    /**
     * Establece el nombre de la casa de apuestas en la configuraci�n.
     * @param nombre El nuevo nombre de la casa de apuestas.
     */
    public void establecerNombreCasaApuestas(String nombre) {
        properties.setProperty("nombreCasaApuestas", nombre);
    }

    /**
     * Obtiene el n�mero de sedes desde la configuraci�n.
     * @return El n�mero de sedes o 3 por defecto.
     */
    public int obtenerNumeroSedes() {
        return Integer.parseInt(properties.getProperty("numeroSedes", "3"));
    }
    
    /**
     * Establece el n�mero de sedes en la configuraci�n.
     * @param numeroSedes El nuevo n�mero de sedes.
     */
    public void establecerNumeroSedes(int numeroSedes) {
        properties.setProperty("numeroSedes", String.valueOf(numeroSedes));
    }

    /**
     * Obtiene el presupuesto total desde la configuraci�n.
     * @return El presupuesto total o 1000000 por defecto.
     */
    public double obtenerPresupuestoTotal() {
        return Double.parseDouble(properties.getProperty("presupuestoTotal", "1000000"));
    }

    /**
     * Establece el presupuesto total en la configuraci�n.
     * @param presupuestoTotal El nuevo presupuesto total.
     */
    public void establecerPresupuestoTotal(double presupuestoTotal) {
        properties.setProperty("presupuestoTotal", String.valueOf(presupuestoTotal));
    }
}
