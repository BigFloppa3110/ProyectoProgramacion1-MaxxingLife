package co.edu.unbosque.Controller;

import java.util.ArrayList;
import java.io.*;
import co.edu.unbosque.Model.*;

/**
 * 
 * 
 * @author Jose Suarez
 * 
 * 
 */

/**
 * La clase {LoteriaApuestaController} gestiona las apuestas espec�ficas de Loter�a.
 * Extiende la funcionalidad de {ApuestaController} para incluir operaciones relacionadas con la Loter�a.
 */
public class LoteriaApuestaController extends ApuestaController {
    private ArrayList<LoteriaApuestaModel> loteriaApuestas;

    /**
     * Constructor de la clase {LoteriaApuestaController}.
     * Inicializa la lista de apuestas de Loter�a.
     */
    public LoteriaApuestaController() {
        loteriaApuestas = new ArrayList<>();
    }

    /**
     * Crea una nueva apuesta de Loter�a y la agrega a la lista.
     * @param sede La sede de la apuesta.
     * @param cedula La c�dula del apostador.
     * @param dia El d�a de la apuesta.
     * @param valorApuesta El valor de la apuesta.
     * @param nombreLoteria El nombre de la Loter�a.
     * @param numeros Los n�meros seleccionados en la apuesta.
     * @param serie La serie de la Loter�a.
     */
    public void crearLoteriaApuesta(String sede, String cedula, String dia, double valorApuesta, String nombreLoteria, int[] numeros, String serie) {
        LoteriaApuestaModel apuesta = new LoteriaApuestaModel(sede, cedula, dia, valorApuesta, nombreLoteria, numeros, serie);
        loteriaApuestas.add(apuesta);
    }

    /**
     * Guarda las apuestas de Loter�a en el archivo correspondiente.
     */
    public void guardarLoteriaApuestas() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("apuestas-loteria.dat"))) {
            oos.writeObject(loteriaApuestas);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
