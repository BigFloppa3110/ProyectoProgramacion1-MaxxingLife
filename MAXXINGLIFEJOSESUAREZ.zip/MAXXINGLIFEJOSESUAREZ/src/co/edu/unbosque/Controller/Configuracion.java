package co.edu.unbosque.Controller;

import java.io.*;
import java.util.Properties;

/**
 * 
 * 
 * @author Jose Suarez
 * 
 * 
 */

/**
 * La clase {configuracion} gestiona la configuraci�n de la Casa de Apuestas.
 * Permite establecer y obtener el nombre de la casa de apuestas, el n�mero de sedes y el presupuesto total.
 */
public class Configuracion {
    private String nombreCasaApuestas;
    private int numeroSedes;
    private double presupuestoTotal;

    /**
     * Constructor de la clase {Configuracion}.
     * Inicializa valores predeterminados o carga la configuraci�n desde el archivo si existe.
     */
    public Configuracion() {
        cargarConfiguracion();
    }

    /**
     * Obtiene el nombre de la casa de apuestas.
     * @return El nombre de la casa de apuestas.
     */
    public String getNombreCasaApuestas() {
        return nombreCasaApuestas;
    }

    /**
     * Establece el nombre de la casa de apuestas y guarda la configuraci�n.
     * nombreCasaApuestas El nuevo nombre de la casa de apuestas.
     */
    public void setNombreCasaApuestas(String nombreCasaApuestas) {
        this.nombreCasaApuestas = nombreCasaApuestas;
        guardarConfiguracion();
    }

    /**
     * Obtiene el n�mero de sedes de la casa de apuestas.
     * @return El n�mero de sedes.
     */
    public int getNumeroSedes() {
        return numeroSedes;
    }

    /**
     * Establece el n�mero de sedes y guarda la configuraci�n.
     * numeroSedes El nuevo n�mero de sedes.
     */
    public void setNumeroSedes(int numeroSedes) {
        this.numeroSedes = numeroSedes;
        guardarConfiguracion();
    }

    /**
     * Obtiene el presupuesto total de la casa de apuestas.
     * @return El presupuesto total.
     */
    public double getPresupuestoTotal() {
        return presupuestoTotal;
    }

    /**
     * Establece el presupuesto total y guarda la configuraci�n.
     * presupuestoTotal El nuevo presupuesto total.
     */
    public void setPresupuestoTotal(double presupuestoTotal) {
        this.presupuestoTotal = presupuestoTotal;
        guardarConfiguracion();
    }

    /**
     * Carga la configuraci�n desde el archivo de propiedades.
     */
    private void cargarConfiguracion() {
        Properties properties = new Properties();

        try (InputStream input = new FileInputStream("config.properties")) {
            properties.load(input);

            nombreCasaApuestas = properties.getProperty("nombreCasaApuestas", "Casa de Apuestas");
            numeroSedes = Integer.parseInt(properties.getProperty("numeroSedes", "1"));
            presupuestoTotal = Double.parseDouble(properties.getProperty("presupuestoTotal", "100000.0"));

        } catch (IOException | NumberFormatException e) {
            e.printStackTrace();
        }
    }

    /**
     * Guarda la configuraci�n en el archivo de propiedades.
     */
    private void guardarConfiguracion() {
        Properties properties = new Properties();

        try (OutputStream output = new FileOutputStream("config.properties")) {
            properties.setProperty("nombreCasaApuestas", nombreCasaApuestas);
            properties.setProperty("numeroSedes", String.valueOf(numeroSedes));
            properties.setProperty("presupuestoTotal", String.valueOf(presupuestoTotal));
            properties.store(output, "Configuraci�n de la Casa de Apuestas");

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
