package co.edu.unbosque.Controller;

import java.util.ArrayList;
import java.io.*;
import java.util.List;
import co.edu.unbosque.Model.*;

/**
 * 
 * 
 * @author Jose Suarez
 * 
 * 
 */

/**
 * La clase {SedeController} gestiona las operaciones relacionadas con las sedes de la casa de apuestas.
 * Permite crear, obtener y guardar informaci�n sobre las sedes.
 */
public class SedeController {
    private ArrayList<SedeModel> sedes;

    /**
     * Constructor de la clase {SedeController}.
     * Inicializa la lista de sedes.
     */
    public SedeController() {
        sedes = new ArrayList<>();
    }

    /**
     * Crea una nueva sede y la agrega a la lista.
     * @param ubicacion La ubicaci�n de la sede.
     * @param numeroEmpleados El n�mero de empleados de la sede.
     */
    public void crearSede(String ubicacion, int numeroEmpleados) {
        SedeModel sede = new SedeModel(ubicacion, numeroEmpleados);
        sede.setUbicacion(ubicacion);
        sede.setNumeroEmpleados(numeroEmpleados);
        sedes.add(sede);
    }
    
    /**
     * Obtiene la lista de sedes.
     * @return La lista de sedes.
     */
    public List<SedeModel> obtenerSedes() {
        return sedes;
    }

    /**
     * Guarda las sedes en el archivo correspondiente.
     */
    public void guardarSedes() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("sedes.dat"))) {
            oos.writeObject(sedes);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Obtiene una sede por su ubicaci�n.
     * @param ubicacion La ubicaci�n de la sede a buscar.
     * @return La sede correspondiente a la ubicaci�n especificada, o null si no se encuentra.
     */
    public SedeModel obtenerSedePorUbicacion(String ubicacion) {
        for (SedeModel sede : sedes) {
            if (sede.getUbicacion().equalsIgnoreCase(ubicacion)) {
                return sede;
            }
        }
        return null;
    }
}
