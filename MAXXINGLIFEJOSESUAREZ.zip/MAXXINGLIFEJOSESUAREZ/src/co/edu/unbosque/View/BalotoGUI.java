package co.edu.unbosque.View;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * 
 * 
 * @author Jose Suarez
 * 
 * 
 */

/**
 * La clase {BalotoGUI} representa la interfaz gr�fica para el juego de Baloto.
 * Permite a los jugadores seleccionar n�meros y verificar si son ganadores.
 */
public class BalotoGUI extends JFrame {

    private JComboBox<Integer>[] gruposNumeros;
    private JButton verificarButton;

    /**
     * Constructor de la clase {BalotoGUI}.
     */
    public BalotoGUI() {
        setTitle("Baloto");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); 
        setLayout(new GridLayout(5, 1));

        gruposNumeros = new JComboBox[4];
        for (int i = 0; i < gruposNumeros.length; i++) {
            gruposNumeros[i] = new JComboBox<>();
            for (int num = 1; num <= 45; num++) {
                gruposNumeros[i].addItem(num);
            }
            add(new JLabel("Grupo " + (i + 1)));
            add(gruposNumeros[i]);
        }

        verificarButton = new JButton("Verificar N�meros Ganadores");
        add(verificarButton);
        verificarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                verificarNumerosGanadores();
            }
        });

        setVisible(true);
    }

    /**
     * M�todo privado para verificar si los n�meros seleccionados son ganadores.
     */
    private void verificarNumerosGanadores() {
        int[][] gruposSeleccionados = new int[gruposNumeros.length][6];
        for (int i = 0; i < gruposNumeros.length; i++) {
            for (int j = 0; j < 6; j++) {
                gruposSeleccionados[i][j] = (int) gruposNumeros[i].getSelectedItem();
            }
        }

        boolean sonGanadores = esNumeroGanador(gruposSeleccionados);

        if (sonGanadores) {
            JOptionPane.showMessageDialog(this, "�Felicidades! Has acertado los n�meros ganadores.");
        } else {
            int[] numerosGanadores = obtenerNumerosGanadores();
            JOptionPane.showMessageDialog(this, "Lo siento, no has acertado los n�meros ganadores. Los n�meros ganadores fueron: " + arrayToString(numerosGanadores) + ". �Int�ntalo de nuevo!");
        }
    }

    /**
     * M�todo privado para determinar si al menos un n�mero seleccionado es ganador.
     * @param gruposSeleccionados Los n�meros seleccionados por el jugador.
     * @return true si al menos un n�mero es ganador, false de lo contrario.
     */
    private boolean esNumeroGanador(int[][] gruposSeleccionados) {
        int[] numerosGanadores = obtenerNumerosGanadores();

        for (int[] grupo : gruposSeleccionados) {
            for (int numero : grupo) {
                for (int numeroGanador : numerosGanadores) {
                    if (numero == numeroGanador) {
                        return true;
                    }
                }
            }
        }

        return false; 
    }

    /**
     * M�todo privado para obtener los n�meros ganadores aleatorios.
     * @return Un array con los n�meros ganadores.
     */
    private int[] obtenerNumerosGanadores() {
        int[] numerosGanadores = new int[6];
        for (int i = 0; i < 6; i++) {
            numerosGanadores[i] = (int) (Math.random() * 45) + 1;
        }
        return numerosGanadores;
    }

    /**
     * M�todo privado para convertir un array de n�meros a una cadena de texto.
     * @param array El array de n�meros.
     * @return Una cadena de texto con los n�meros separados por comas.
     */
    private String arrayToString(int[] array) {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < array.length; i++) {
            result.append(array[i]);
            if (i < array.length - 1) {
                result.append(", ");
            }
        }
        return result.toString();
    }

    /**
     * M�todo principal para ejecutar la aplicaci�n.
     * @param args Argumentos de la l�nea de comandos (no se utilizan).
     */
    public static void main(String[] args) {
        new BalotoGUI();
    }
}


