package co.edu.unbosque.View;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

/**
 * 
 * 
 * @author Jose Suarez
 * 
 * 
 */

/**
 * La clase {BetPlayGUI} representa la interfaz gr�fica para el juego de BetPlay.
 * Permite a los jugadores realizar apuestas y verificar los resultados.
 */
public class BetPlayGUI extends JFrame {

    private List<JPanel> panelesPartidos;
    private List<JLabel> labels;
    private List<Integer> resultados;
    private List<List<Integer>> estimaciones;
    private JButton generarResultadosButton;
    private JButton continuarButton;
    private JTextField dineroApostarField;
    private final String[] nombresPartidos = {"Millonarios vs Santa Fe", "America vs Deportivo Cali", "nacional vs DIM",
            "Junior vs U.Magdalena", "Bucaramanga vs Jaguares", "Once Caldas vs Pereira", "Tolima vs envigado"};

    /**
     * Constructor de la clase {BetPlayGUI}.
     */
    public BetPlayGUI() {
        setTitle("BetPlay");
        setSize(900, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); 
        setLayout(new BorderLayout());
        setLayout(new GridLayout(8, 4));

        resultados = new ArrayList<>();
        labels = new ArrayList<>();
        panelesPartidos = new ArrayList<>();
        estimaciones = new ArrayList<>();

        dineroApostarField = new JTextField(10);
        add(new JLabel("Dinero a Apostar: "));
        add(dineroApostarField);

        JButton apostarButton = new JButton("Apostar");
        add(apostarButton);

        apostarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                double dineroApostar = obtenerDineroApostar();
            }
        });

        for (int i = 0; i < 7; i++) {
            JPanel panelPartido = new JPanel(new GridLayout(1, 4));
            JLabel label = new JLabel(nombresPartidos[i]);

            labels.add(label);
            panelPartido.add(label);

            for (int j = 0; j < 2; j++) {
                JTextField textField = new JTextField();
                panelPartido.add(textField);
            }

            panelesPartidos.add(panelPartido);
            add(panelPartido);
        }

        generarResultadosButton = new JButton("Resultados reales");
        add(generarResultadosButton);
        generarResultadosButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                generarResultados();
            }
        });

        continuarButton = new JButton("Continuar");
        continuarButton.setEnabled(false);
        add(continuarButton);
        continuarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mostrarResultadoApuesta();
            }
        });

        setVisible(true);
    }

    /**
     * M�todo privado para obtener la cantidad de dinero a apostar.
     *
     * @return La cantidad de dinero a apostar.
     */
    private double obtenerDineroApostar() {
        try {
            return Double.parseDouble(dineroApostarField.getText());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Ingrese una cantidad de dinero v�lida", "Error", JOptionPane.ERROR_MESSAGE);
            return 0.0;
        }
    }

    /**
     * M�todo privado para generar resultados aleatorios.
     */
    private void generarResultados() {
        resultados.clear();
        estimaciones.clear();

        for (int i = 0; i < 7; i++) {
            List<Integer> estimacionPartido = new ArrayList<>();
            for (Component component : panelesPartidos.get(i).getComponents()) {
                if (component instanceof JTextField) {
                    String resultadoStr = ((JTextField) component).getText();
                    try {
                        int resultado = Integer.parseInt(resultadoStr);
                        estimacionPartido.add(resultado);
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(this, "Por favor, ingrese un n�mero v�lido para todos los equipos.");
                        return;
                    }
                }
            }
            estimaciones.add(estimacionPartido);
        }

        if (resultados.isEmpty()) {
            for (int i = 0; i < 7; i++) {
                resultados.add((int) (Math.random() * 6));
            }
            generarResultadosButton.setEnabled(false);
            continuarButton.setEnabled(true);
        }
    }

    /**
     * M�todo privado para mostrar el resultado de la apuesta.
     */
    private void mostrarResultadoApuesta() {
        int resultadosCorrectos = 0;
        for (int i = 0; i < 7; i++) {
            if (i < estimaciones.size()) {
                List<Integer> estimacionPartido = estimaciones.get(i);

                for (int j = 0; j < 2; j++) {
                    int estimacion = estimacionPartido.get(j);
                    JTextField textField = (JTextField) panelesPartidos.get(i).getComponent(j + 1);

                    if (resultados.get(i).equals(estimacion)) {
                        textField.setForeground(Color.GREEN);
                        resultadosCorrectos++;
                    } else {
                        textField.setForeground(Color.RED);
                    }
                }
            }
        }

        if (resultadosCorrectos >= 7) {
            JOptionPane.showMessageDialog(this, "�Felicidades! Ganaste la apuesta.");
        } else {
            JOptionPane.showMessageDialog(this, "Lo siento, no ganaste la apuesta.");
        }
    }

    /**
     * M�todo principal para ejecutar la aplicaci�n.
     *
     * @param args Argumentos de la l�nea de comandos (no se utilizan).
     */
    public static void main(String[] args) {
        new BetPlayGUI();
    }
}

