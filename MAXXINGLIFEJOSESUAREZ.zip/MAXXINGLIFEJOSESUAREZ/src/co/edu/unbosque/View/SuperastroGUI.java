package co.edu.unbosque.View;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * 
 * 
 * @author Jose Suarez
 * 
 * 
 */

/**
 * La clase SuperastroGUI representa la interfaz gr�fica de usuario para el juego de Superastro.
 * Permite a los usuarios seleccionar n�meros y un signo del zodiaco, generando luego resultados aleatorios
 * y compar�ndolos con la selecci�n del usuario.
 */
public class SuperastroGUI extends JFrame {
    private List<JComboBox<Integer>> numerosComboBox;
    private JComboBox<String> signoZodiacoComboBox;

    /**
     * Constructor de la clase. Inicializa y configura la interfaz gr�fica.
     */
    public SuperastroGUI() {
        setTitle("Superastro");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new GridLayout(6, 3));

        numerosComboBox = new ArrayList<>();
        for (int i = 0; i < 4; i++) {
            JComboBox<Integer> numeroComboBox = new JComboBox<>(obtenerNumerosDisponibles());
            numerosComboBox.add(numeroComboBox);
            add(numeroComboBox);
        }

        String[] signosZodiaco = {"Aries", "Tauro", "G�minis", "C�ncer", "Leo", "Virgo", "Libra", "Escorpio", "Sagitario", "Capricornio", "Acuario", "Piscis"};
        signoZodiacoComboBox = new JComboBox<>(signosZodiaco);
        add(signoZodiacoComboBox);

        JButton generarButton = new JButton("Generar Resultados");
        add(generarButton);

        generarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                generarResultados();
            }
        });

        setVisible(true);
    }

    /**
     * Obtiene una matriz de n�meros disponibles (del 0 al 9).
     *
     * @return Un array de Integer con los n�meros disponibles.
     */
    private Integer[] obtenerNumerosDisponibles() {
        return new Integer[]{0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
    }

    /**
     * Genera resultados aleatorios y compara con la selecci�n del usuario,
     * mostrando un mensaje indicando si el usuario ha ganado o no.
     */
    private void generarResultados() {
        List<Integer> combinacionAleatoria = generarCombinacionAleatoria();

        List<Integer> seleccionUsuario = obtenerSeleccionUsuario();

        if (combinacionAleatoria.equals(seleccionUsuario)) {
            JOptionPane.showMessageDialog(this, "�Felicidades! Eres el ganador de Superastro");
        } else {
            String combinacionGanadora = obtenerCombinacionComoString(combinacionAleatoria);
            JOptionPane.showMessageDialog(this, "Sigue participando. La combinaci�n ganadora era: " + combinacionGanadora);
        }
    }

    /**
     * Genera una combinaci�n aleatoria de n�meros y un signo del zodiaco.
     *
     * @return Una lista de Integer representando la combinaci�n aleatoria.
     */
    private List<Integer> generarCombinacionAleatoria() {
        List<Integer> combinacionAleatoria = new ArrayList<>();
        for (int i = 0; i < 4; i++) {
            int numeroAleatorio = (int) (Math.random() * 10);
            combinacionAleatoria.add(numeroAleatorio);
        }

        int indiceZodiacoAleatorio = (int) (Math.random() * signoZodiacoComboBox.getItemCount());
        combinacionAleatoria.add(indiceZodiacoAleatorio);

        return combinacionAleatoria;
    }

    /**
     * Obtiene la selecci�n del usuario desde los ComboBox.
     *
     * @return Una lista de Integer representando la selecci�n del usuario.
     */
    private List<Integer> obtenerSeleccionUsuario() {
        List<Integer> seleccionUsuario = new ArrayList<>();
        for (JComboBox<Integer> comboBox : numerosComboBox) {
            seleccionUsuario.add((Integer) comboBox.getSelectedItem());
        }
        return seleccionUsuario;
    }

    /**
     * Convierte la combinaci�n de n�meros y signo del zodiaco a un formato de cadena.
     *
     * @param combinacion La combinaci�n de n�meros y signo del zodiaco.
     * @return Una cadena que representa la combinaci�n.
     */
    private String obtenerCombinacionComoString(List<Integer> combinacion) {
        StringBuilder combinacionString = new StringBuilder();
        for (int i = 0; i < combinacion.size(); i++) {
            if (i == 4) {
                combinacionString.append(signoZodiacoComboBox.getItemAt(combinacion.get(i)));
            } else {
                combinacionString.append(combinacion.get(i));
            }
            if (i < combinacion.size() - 1) {
                combinacionString.append(" ");
            }
        }
        return combinacionString.toString();
    }

    /**
     * M�todo principal para ejecutar la aplicaci�n.
     *
     * @param args Argumentos de l�nea de comandos (no se utilizan en este caso).
     */
    public static void main(String[] args) {
        new SuperastroGUI();
    }
}
