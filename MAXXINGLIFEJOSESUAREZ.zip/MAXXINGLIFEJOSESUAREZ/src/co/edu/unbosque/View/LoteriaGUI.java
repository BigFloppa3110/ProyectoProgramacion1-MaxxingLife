package co.edu.unbosque.View;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

/**
 * 
 * 
 * @author Jose Suarez
 * 
 * 
 */

/**
 * La clase LoteriaGUI representa la interfaz gr�fica de usuario para el juego de Loter�a.
 * Permite a los usuarios seleccionar tiquetes y verificar si son ganadores.
 */
public class LoteriaGUI extends JFrame {

    private List<JButton> tiquetes;
    private int tiqueteGanador;

    /**
     * Constructor de la clase. Inicializa y configura la interfaz gr�fica.
     */
    public LoteriaGUI() {
        setTitle("Loter�a");
        setSize(500, 500);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new GridLayout(3, 3, 5, 5));

        tiquetes = new ArrayList<>();

        for (int i = 1; i <= 9; i++) {
            JButton tiqueteButton = new JButton("Tiquete " + i);
            tiqueteButton.setPreferredSize(new Dimension(80, 40)); 
            tiqueteButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    verificarGanador((JButton) e.getSource());
                }
            });
            tiquetes.add(tiqueteButton);
            add(tiqueteButton);
        }

        setVisible(true);

        tiqueteGanador = (int) (Math.random() * 9) + 1;
    }

    /**
     * Verifica si el tiquete seleccionado es el ganador y muestra un mensaje al usuario.
     *
     * @param tiqueteButton El bot�n de tiquete seleccionado por el usuario.
     */
    private void verificarGanador(JButton tiqueteButton) {
        for (JButton button : tiquetes) {
            button.setEnabled(false);
        }

        String mensaje;
        if (tiquetes.indexOf(tiqueteButton) + 1 == tiqueteGanador) {
            mensaje = "�Ganador!";
        } else {
            mensaje = "Sigue intentando.";
        }
        mensaje += "\nN�meros ganadores: " + tiqueteGanador;

        JOptionPane.showMessageDialog(this, mensaje, "Resultado", JOptionPane.INFORMATION_MESSAGE);

        this.dispose();
    }

    /**
     * M�todo principal para ejecutar la aplicaci�n.
     *
     * @param args Argumentos de l�nea de comandos (no se utilizan en este caso).
     */
    public static void main(String[] args) {
        new LoteriaGUI();
    }
}

