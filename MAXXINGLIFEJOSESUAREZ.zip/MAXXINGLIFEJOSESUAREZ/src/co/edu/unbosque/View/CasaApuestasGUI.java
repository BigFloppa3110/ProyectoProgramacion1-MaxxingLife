package co.edu.unbosque.View;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;
import co.edu.unbosque.Controller.*;
import co.edu.unbosque.Model.*;

/**
 * 
 * 
 * @author Jose Suarez
 * 
 * 
 */

/**
 * Representa la interfaz gr�fica principal para la aplicaci�n Casa de Apuestas.
 * Esta clase gestiona las interacciones del usuario e interact�a con los controladores de diferentes juegos.
 */
public class CasaApuestasGUI extends JFrame {
	private JComboBox<String> juegoComboBox;
    private JButton registrarApostadorButton;
    private JButton eliminarApostadorButton;
    private JButton ingresarButton; 
    private JButton informacionApostadoresButton;
    private JButton imprimirFacturaButton;
    private Configuracion configuracion;
    private ApuestaController apuestaController;
    private ApostadorController apostadorController;
    private ApostadorModel apostadorActual;
    private ArrayList<JuegoModel> juegos;
	private Container frame;

    public CasaApuestasGUI() {
        configuracion = new Configuracion();
        setTitle("MaxxingLife");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new FlowLayout(FlowLayout.CENTER, 50, 50)); 

        juegoComboBox = new JComboBox<>(new String[]{"Loter�a", "Superastro", "Baloto", "BetPlay", "Chance"});
        registrarApostadorButton = new JButton("Registrar Apostador");
        eliminarApostadorButton = new JButton("Eliminar Apostador");
        ingresarButton = new JButton("Ingresar");
        informacionApostadoresButton = new JButton("Informaci�n de Apostadores");
        imprimirFacturaButton = new JButton("imprimirFactura");
        apuestaController = new ApuestaController();
        apostadorController = new ApostadorController();
        
        ingresarButton.setEnabled(false);

        add(juegoComboBox);
        add(registrarApostadorButton);
        add(eliminarApostadorButton);
        add(ingresarButton);
        add(informacionApostadoresButton);
        add(imprimirFacturaButton);

        
        registrarApostadorButton.setBackground(Color.cyan);
        eliminarApostadorButton.setBackground(Color.red);
        ingresarButton.setBackground(Color.cyan);
        
        informacionApostadoresButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mostrarInformacionApostadores();
            }
        });

        registrarApostadorButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String juegoSeleccionado = (String) juegoComboBox.getSelectedItem();
                registrarApostador(juegoSeleccionado);
                ingresarButton.setEnabled(true);
            }
        });
        
        eliminarApostadorButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                eliminarApostador();
            }
        });
        
        
        ingresarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String juegoSeleccionado = (String) juegoComboBox.getSelectedItem();
                ingresarJuego(juegoSeleccionado);
            }
        });
        
        JButton modificarNombreButton = new JButton("Modificar Nombre");
        modificarNombreButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nuevoNombre = JOptionPane.showInputDialog("Ingrese el nuevo nombre:");
                configuracion.setNombreCasaApuestas(nuevoNombre);
            }
        });

        apuestaController = new ApuestaController();
        System.out.println("ApuestaController inicializado correctamente.");
    }

    private void mostrarInformacionApostadores() {
        ApostadorController apostadorController = new ApostadorController();
        List<ApostadorModel> apostadores = apostadorController.obtenerApostadores();
        apostadorController.cargarApostadores();
        apostadorController.imprimirInformacionApostadores();
        
        if (apostadores.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No hay apostadores registrados.", "Informaci�n de Apostadores", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        

        StringBuilder mensaje = new StringBuilder("Informaci�n de Apostadores:\n\n");
        

        for (ApostadorModel apostador : apostadores) {
            mensaje.append("Nombre: ").append(apostador.getNombreCompleto()).append("\n");
            mensaje.append("C�dula: ").append(apostador.getCedula()).append("\n");
            mensaje.append("Sede: ").append(apostador.getSede()).append("\n");
            mensaje.append("Direcci�n: ").append(apostador.getDireccion()).append("\n");
            mensaje.append("Celular: ").append(apostador.getCelular()).append("\n\n");
        }

        JOptionPane.showMessageDialog(this, mensaje.toString(), "Informaci�n de Apostadores", JOptionPane.INFORMATION_MESSAGE);
    }
    

    
    public void registrarVictoria(String nombreJuego, double dineroInvertido) {
        JuegoModel juego = buscarJuego(nombreJuego);

        if (juego != null) {
            juego.setVictorias(juego.getVictorias() + 1);
            juego.setDineroInvertido(juego.getDineroInvertido() + dineroInvertido);
            guardarJuegos();
        }
    }
    
    private JuegoModel buscarJuego(String nombreJuego) {
        for (JuegoModel juego : juegos) {
            if (juego.getNombreJuego().equals(nombreJuego)) {
                return juego;
            }
        }
        return null;
    }
    
    
    
    private void cargarJuegos() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("juegos.dat"))) {
            Object obj = ois.readObject();

            if (obj instanceof ArrayList<?>) {
                juegos = (ArrayList<JuegoModel>) obj;
            } else {
                System.out.println("Error: El objeto le�do no es una instancia de ArrayList<JuegoModel>");
            }
        } catch (FileNotFoundException e) {
            System.out.println("El archivo juegos.dat no existe. Se crear� uno nuevo.");
            juegos = new ArrayList<>();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    private void guardarJuegos() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("juegos.dat"))) {
            oos.writeObject(juegos);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    
    public void setApostadorActual(ApostadorModel apostador) {
        this.apostadorActual = apostador;
    }
    
    private void crearPanelJuego() {
        JPanel panelJuego = new JPanel();

        JLabel lblCantidadDinero = new JLabel("Cantidad de Dinero a Apostar:");
        JTextField txtCantidadDinero = new JTextField(10);
        JButton btnApostar = new JButton("Apostar");

        btnApostar.addActionListener(e -> {
            String cantidadDineroStr = txtCantidadDinero.getText();

            try {
                double cantidadDinero = Double.parseDouble(cantidadDineroStr);

                JOptionPane.showMessageDialog(this, "Apuesta realizada con �xito.");

                txtCantidadDinero.setText("");
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Ingrese una cantidad de dinero v�lida.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        panelJuego.add(lblCantidadDinero);
        panelJuego.add(txtCantidadDinero);
        panelJuego.add(btnApostar);

        frame.add(panelJuego);
    }
    
    private void registrarApostador(String juegoSeleccionado) {
        String nombreJuego = "apuestas-" + juegoSeleccionado.toLowerCase() + ".dat";
        String nombreApostador = JOptionPane.showInputDialog("Ingrese el nombre del apostador:");
        String cedulaApostador = JOptionPane.showInputDialog("Ingrese la c�dula del apostador:");
        String sedeApostador = JOptionPane.showInputDialog("Ingrese la Sede:");
        String direccionApostador = JOptionPane.showInputDialog("Ingrese la Direccion del apostador:");
        String celularApostador = JOptionPane.showInputDialog("Ingrese la Celular del apostador:");
        String presupuestoApostador = JOptionPane.showInputDialog("Ingrese el presupuesto del apostador:");
        
        ApostadorModel nuevoApostador = new ApostadorModel(nombreApostador, cedulaApostador, sedeApostador, direccionApostador, celularApostador);
        apostadorController.guardarApostadores();
        apostadorController.imprimirInformacionApostadores();
        apostadorController.registrarApostador(nuevoApostador);

        switch (juegoSeleccionado) {
            case "Loter�a":
                int[] numerosLoteria = {1, 2, 3, 4};
                String serieLoteria = JOptionPane.showInputDialog("Ingrese la serie de la Loter�a");
                apuestaController.crearLoteriaApuesta("Sede", cedulaApostador, "Lunes", 10.0, "Loter�a Nacional", numerosLoteria, serieLoteria);
                break;
        }

        JOptionPane.showMessageDialog(this, "Apostador registrado exitosamente.");
        System.out.println("Apostadores registrados: " + apostadorController.obtenerApostadores().size());
    }

    private void eliminarApostador() {
        String cedulaApostador = JOptionPane.showInputDialog("Ingrese la c�dula del apostador a eliminar:");
        apostadorController.eliminarApostador(cedulaApostador);
        apostadorController.guardarApostadores(); // Aseg�rate de guardar los cambios en los apostadores
        apostadorController.imprimirInformacionApostadores();
        JOptionPane.showMessageDialog(this, "Datos del apostador eliminados exitosamente.");
    }


    
    private void ingresarJuego(String juegoSeleccionado) {
        switch (juegoSeleccionado.toLowerCase()) {
            case "loter�a":
                new LoteriaGUI();
                JOptionPane.showMessageDialog(this, "Ingresando a la interfaz de Loter�a");
                break;
            case "superastro":
                new SuperastroGUI();
                JOptionPane.showMessageDialog(this, "Ingresando a la interfaz de Superastro");
                break;
            case "baloto":
                new BalotoGUI();
                JOptionPane.showMessageDialog(this, "Ingresando a la interfaz de Baloto");
                break;
            case "betplay":
                new BetPlayGUI();
                JOptionPane.showMessageDialog(this, "Ingresando a la interfaz de BetPlay");
                break;
            case "chance":
                new ChanceGUI();
                JOptionPane.showMessageDialog(this, "Ingresando a la interfaz de Chance");
                break;
            default:
                JOptionPane.showMessageDialog(this, "Juego no reconocido", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new CasaApuestasGUI().setVisible(true);
            }
        });
    }
}


