package co.edu.unbosque.View;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

/**
 * 
 * 
 * @author Jose Suarez
 * 
 * 
 */

/**
 * La clase ChanceGUI representa la interfaz gr�fica de usuario para el juego Chance.
 * Permite a los usuarios seleccionar tiquetes y verificar si son ganadores.
 */
public class ChanceGUI extends JFrame {

    private List<JButton> botonesTiquetes;
    private int tiqueteGanador;

    /**
     * Constructor de la clase. Inicializa y configura la interfaz gr�fica.
     */
    public ChanceGUI() {
        setTitle("Chance");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new GridLayout(6, 1));

        botonesTiquetes = new ArrayList<>();

        for (int i = 0; i < 5; i++) {
            JButton botonTiquete = new JButton("Tiquete " + (i + 1));
            botonesTiquetes.add(botonTiquete);

            add(botonTiquete);

            botonTiquete.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    mostrarResultado(botonesTiquetes.indexOf(botonTiquete));
                }
            });
        }

        tiqueteGanador = (int) (Math.random() * 5);

        for (JButton botonTiquete : botonesTiquetes) {
            botonTiquete.setEnabled(false);
        }

        JButton continuarButton = new JButton("Continuar");
        add(continuarButton);

        continuarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                habilitarTiquetes();
            }
        });

        setVisible(true);
    }

    /**
     * Muestra el resultado del juego al usuario seg�n el tiquete seleccionado.
     *
     * @param tiqueteSeleccionado El �ndice del tiquete seleccionado por el usuario.
     */
    private void mostrarResultado(int tiqueteSeleccionado) {
        if (tiqueteSeleccionado == tiqueteGanador) {
            JOptionPane.showMessageDialog(this, "�Felicidades! Has ganado el juego Chance.");
        } else {
            int[] numerosGanadores = obtenerNumerosGanadores();
            String mensaje = "Lo siento, no has ganado. Mejor suerte la pr�xima vez.\n\n";
            mensaje += "N�meros ganadores: ";
            for (int numero : numerosGanadores) {
                mensaje += numero + " ";
            }
            JOptionPane.showMessageDialog(this, mensaje);
        }

        for (JButton botonTiquete : botonesTiquetes) {
            botonTiquete.setEnabled(false);
        }

        JButton continuarButton = (JButton) getContentPane().getComponent(5);
        continuarButton.setEnabled(true);
    }

    /**
     * Habilita los botones de los tiquetes y deshabilita el bot�n de continuar.
     */
    private void habilitarTiquetes() {
        for (JButton botonTiquete : botonesTiquetes) {
            botonTiquete.setEnabled(true);
        }

        JButton continuarButton = (JButton) getContentPane().getComponent(5);
        continuarButton.setEnabled(false);
    }

    /**
     * Genera y devuelve n�meros aleatorios como resultado del juego.
     *
     * @return Un arreglo de enteros representando los n�meros ganadores.
     */
    private int[] obtenerNumerosGanadores() {
        int[] numerosGanadores = new int[4];
        for (int i = 0; i < 4; i++) {
            numerosGanadores[i] = (int) (Math.random() * 10); 
        }
        return numerosGanadores;
    }

    /**
     * M�todo principal para ejecutar la aplicaci�n.
     *
     * @param args Argumentos de l�nea de comandos (no se utilizan en este caso).
     */
    public static void main(String[] args) {
        new ChanceGUI();
    }
}
